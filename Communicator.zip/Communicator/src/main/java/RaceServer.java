import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import static java.nio.charset.StandardCharsets.UTF_16BE;

public class RaceServer {
    private Communicator communicator;
    private ArrayList<Racer> racers;
    private ArrayList<Client> clients;
    private Boolean done;

    public RaceServer() throws SocketException {
        this.racers = new ArrayList<Racer>();
        this.clients = new ArrayList<Client>();
        this.communicator = new Communicator(12000);
        done = false;
    }


    /**
     * @param client
     */
    public void register(Client client) {
        this.clients.add(client);
    }


    /**
     * @param client
    //     */
//    public void unregister(Client client) {
//        this.Clients.remove(client);
//    }


    /**
     * @param message
     */
    public void notifyClients(Message message) {
        for (Client client : this.clients) {
            client.update(this.racers, this.communicator);
        }
    }

    public void run() {
        while (!done) {
            DatagramPacket packet = null;
            try {
                packet = this.communicator.getMessage();
            } catch (Exception e) { /* ignore */ }
            if (packet == null) continue;
            String message = new String(packet.getData(), 0, packet.getLength(), UTF_16BE);
            System.out.println(message);
            InetAddress senderAddress = packet.getAddress();
            Message messageToParse = new Message(message);
            if (message.equals("Hello")) {
                try {
                    this.communicator.send("Race,theOnlyRace,100000000", senderAddress, 12000);
                    this.communicator.send("Athlete,20,Juan,Montigo,12,69", senderAddress, 12000);

                }
                catch (Exception e){

                }
                Client client = new Client(this.racers, this.communicator, senderAddress);
                this.register(client);
            } else if (messageToParse.getType().equals("Subscribe")) {
                Racer racerToAdd = null;
                for (Racer racer : this.racers) {
                    if (racer.getBibNumber() == messageToParse.getField().split(",")[1]) {
                        racerToAdd = racer;
                    }

                }
                for (Client client : this.clients) {
                    client.register(racerToAdd, senderAddress);
                }
            } else if (messageToParse.getType().equals("Unsubscribe")) {
                Racer racerToAdd = null;
                for (Racer racer : this.racers) {
                    if (racer.getBibNumber() == messageToParse.getField().split(",")[1]) {
                        racerToAdd = racer;
                    }

                }
                for (Client client : this.clients) {
                    client.unRegister(racerToAdd, senderAddress);
                }
            } else {
                this.updateRacers(messageToParse);
                this.notifyClients(messageToParse);

            }
        }
    }

    private void updateRacers(Message message) {
        if (message.getType().equals("Registered")) {
            Racer newRacer = new Racer(message);
            this.racers.add(newRacer);
        } else {
            for (Racer racer : this.racers) {
                racer.update(message);
            }
        }

    }
}
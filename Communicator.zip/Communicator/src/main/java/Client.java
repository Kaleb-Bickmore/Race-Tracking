import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;

public class Client{

	private ArrayList<String> bibsSubscribed;
	private InetAddress clientAddress;
	private Communicator communicator;
	/**
	 * 
	 * @param allRacers
	 */
	public Client(ArrayList<Racer> allRacers, Communicator communicator, InetAddress clientAddress) {
	    this.bibsSubscribed = new ArrayList<String>();
		this.clientAddress = clientAddress;
		this.communicator = communicator;
//		System.out.println("sending racer info...");
//		System.out.print(allRacers);
//		try {
//            this.communicator.send("Race,theOnlyRace,100000000", clientAddress, 12000);
//        }
//        catch(Exception e){
//		    System.out.println("Houston has a problem...");
//        }
//		for(Racer racer : allRacers){
//		    try {
//                this.communicator.send("Athlete," + racer.getBibNumber() + ","
//                        + racer.getFirstName() + "," + racer.getLastName() + "," + racer.getGender() + "," + racer.getAge(), clientAddress, 12000);
//            }
//            catch (Exception e){
//		        System.out.println(e.getMessage());
//            }
		    //TODO
		    //send the new athlete message to the client address
        //}
	}

	/**
	 * 
	 * @param racers
	 */
	public void update(ArrayList <Racer> racers, Communicator communicator) {
        for (String bibs : this.bibsSubscribed){
            for(Racer racer : racers){
                if(racer.getBibNumber() ==  bibs ){
                    //todo
                    //send a message
                }
          }

        }
	}

	/**
	 * 
	 * @param racer
	 */
	public void register(Racer racer , InetAddress clientAddress) {
        if(racer ==null||clientAddress != this.clientAddress) return;
            bibsSubscribed.add(racer.getBibNumber());
            //TODO
            //send status update to client
	}

	/**
	 * 
	 * @param racer
	 */
	public void unRegister(Racer racer ,  InetAddress clientAddress) {
        if(racer ==null||clientAddress != this.clientAddress) return;
            this.bibsSubscribed.remove(racer.getBibNumber());
    }

}